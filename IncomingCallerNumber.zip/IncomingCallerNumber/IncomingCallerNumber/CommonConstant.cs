﻿namespace IncomingCallerNumber
{
   public class CommonConstant
    {
        public static string ComportName = "COM2";
        public static string baudRate = "9600";
        public static string portCommand = "AT#CID=1";

    }
}
